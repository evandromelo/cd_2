# Curso: Ci�ncia de Dados para Engenharia Agr�cola - UFV

Reposit�rio com notebooks corrigidos e aplicados � pesquisa agr�cola.

## Como usar
1. Abra os notebooks no [Google Colab](https://colab.research.google.com) ou Jupyter
2. Execute c�lula por c�lula
3. Adapte para seus dados reais

Desenvolvido pelo PPG Engenharia Agr�cola - UFV
